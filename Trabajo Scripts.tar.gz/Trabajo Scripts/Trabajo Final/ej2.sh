#!/bin/bash
#Autor: Javier González, Antonio Cuesta, José Francisco Aguza Benitez
#Versión: 1.0
#Fecha: 17/05/2024
#Descripción: Este script se encarga de comprobar si apache2 
#esta funcionando o no y si no está funcionando o de cualquier 
#error a la hora de iniciarlo nos redirecciona el error a /root/apacheError.tmp 
#Parámetros/Variables

#Funciones...................................................
bloquearUsuario() {
    clear
    echo "Bloqueando al usuario $1..."
    sleep 1
    sudo usermod -L "$1"
}
desbloquearUsuario() {
    clear
    echo "Desbloqueando al usuario $1..."
    sleep 1
    sudo usermod -U "$1"
}

usuariosBloqueados(){
    echo "Monstrando usuarios Bloqueados..."
    sleep 0.5
    for line in $(passwd -S -a |awk '/L/{print $1}')
        do
            echo "$line"
            sleep 0.2
        done
    sleep 1

}

cerrarSesion(){

    clear
    echo "Buscando al usuario $1..."
    sleep 1
    if [ "$(comprobarTiempoUsuario "$1")" -gt 1 ]
        then
            echo "Se encontró al usuario $1..."
            sleep 0.2
            #Se cierra la sesion del usuario.
            echo "Cerrando sesión del usuario $1.."
            sleep 0.2
            pkill -9 -u "$1"

        else
            #No hace falta cerrar la sesion del usuario.
            echo "El usuario $1 todavía está activo..."
    fi
    sleep 1
}
comprobarTiempoUsuario() {
    
    for line in $(w -h | awk '{ print $1"|"$5 }')
        do
        usuario=$(echo "$line" | cut -d'|' -f 1)
        if [ "$usuario" = "$1" ]
                then
                    echo "$line"| cut -d'|' -f 2  | awk -F: '{ print ($1*60 + $2) }'
                    break
                else
                    .
        fi
    done
    
}

menu() {
    clear
    echo "---------------------------------"
    echo "---Menú de usuarios bloqueados---"
    echo "---------------------------------"
    echo "1. Usuarios Bloqueados"
    echo "2. Bloquear un Usuaario"
    echo "3. Desbloquear un Usuario"
    echo "4. Cerrar sesión usuario"
    echo "5. Salir"
}
#............................................................

#Bloque principal............................................

if [ "$(id -u)" -eq 0 ] #Comprueba si eres root
    then

        while true ; do
        menu
        read -rp "Selecciona una opción: " num
        case $num in 
            1)
                #Mostrar listado de usuarios bloq
                usuariosBloqueados
            ;;
            2)
                #Añadir usuario al listado
                read -rp "Nombre del usuario a bloquear :" user
                bloquearUsuario "$user"
            ;;
            3)
                #Eliminar usuario del listado
                read -rp "Nombre del usuario a desbloquear :" user
                desbloquearUsuario "$user"
            ;;
            4)
                #Cerrar sesión del usuario;
                read -rp "Nombre de usuario al cual cerrarle la sesión en este equipo: " user
                cerrarSesion "$user"
            ;;
            5)
                exit
            ;;
        esac 

done
    else
        echo "No eres root"
        exit
fi
