#!/bin/bash
#Autor: Javier González, Antonio Cuesta, José Francisco Aguza Benitez
#Versión: 1.0
#Fecha: ...
#Descripción: Este script se encarga de comprobar si apache2 esta funcionando 
#o no y si no está funcionando o de cualquier error a la hora de iniciarlo nos 
#redirecciona el error a /root/apacheError.tmp 

#Parámetros/Variables

#Funciones................................................................
reiniciarApache() {
    systemctl restart apache2
}

errorApache() {
    echo "Se va a imprimir este error apache2 a un archivo externo en /root/apacheError.tmp..."
    echo "Error-Apache: $(date '+%d-%m-%Y %H:%M')" >> /root/apacheError.tmp
}
#.........................................................................

#Bloque principal.........................................................
clear
if [ "$(id -u)" -eq 0 ] #Comprueba si eres root
then
    systemctl is-active --quiet apache2 2> /dev/null
    if [ $? -eq 0 ]
        then
            #Si apache2 funciona.
            echo "Apache está funcionando."
        else
            #Si apache2 no funciona.
            echo "Apache no está funcionando en estos momentos."
            sleep 1
            errorApache
            sleep 1
            echo "Reiniciando Apache..."
            sleep 1
            reiniciarApache
            echo "Terminado."
    fi
else
    echo "No eres root"
 fi

