#!/bin/bash
#Autor: Javier González, Antonio Cuesta, José Francisco
#Versión: 1.0
#Fecha: ...
#Descripción: Este script realiza una copia de las cuotas del usuario1 a todos
#los usuarios cuyo uid >1000 y uid<2000

#Parámetros/Variables
soft_quota=$(sudo -u usuario1 quota -s | awk 'NR==3{print $3}')
hard_quota=$(sudo -u usuario1 quota -s | awk 'NR==3{print $4}')
#Funciones................................................................
#.........................................................................

#Bloque principal.........................................................
clear
for user in $(awk -F: '$3 >= 1000 && $3 < 2000 {print $1}' /etc/passwd);
do    
	edquota -p usuario1 $user
	echo "Cuota establecida para:  $user: soft=$soft_quota, hard=$hard_quota"
done

echo "Operación completada con éxito."