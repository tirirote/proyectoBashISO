#!/bin/bash
#Autor: Javier González, Antonio Cuesta, José Francisco Aguza Benitez
#Versión: 1.0
#Fecha: ...
#Descripción: Este script se encarga de crear usuarios de forma masiva
#crea un usuario con un nombre pedido en consola y crea una 
#cantidad de usuarios determinado por otro valor pedido en consola 

#Parámetros/Variables
#Funciones................................................................
creaCadaUsuario(){

    echo "Creando usuario $1$2 ..."
    if [ $? -eq 0 ]
        then
            sleep 1
            echo "Asignando contraseña a $1$2..."
            sleep 1
            fichero=usuariosCreados-"$(date +%d-%m-%Y)".txt
            echo "$1$2:$1$2" >> "$fichero"
            echo "Exportando usuario:contraseña a usuariosCreados-$(date).txt"
            sleep 1
        else
        echo "No se ha podido crear el usuario $1"
    fi
}
creaUsuarios() {

    for i in $(seq 1 $2);
        do
            useradd -e 0 "$1$i"
            if [ $? -eq 0 ]
                then
                    creaCadaUsuario "$1" "$i"
                else
                    echo "No se ha podido crear el usuario $1"
            fi


    done
        echo "Terminado."
    preguntarMostrarFichero
            
}
preguntarMostrarFichero(){
    read -rp "¿Desea mostrar el fichero usuariosCreados.txt? (s/n): " mostrar
    if [ "$mostrar" = "s" ]
        then
            cat "$fichero"
            if [ $? -eq 0 ]
            then
                echo "Terminado."
            else
                echo "No se puede mostrar el fichero..."
            fi
    
        else
            exit
    fi
}
#.........................................................................

#Bloque principal.........................................................
if [ "$(id -u)" -eq 0 ] #Comprueba si eres root
    then
        #Si no has introducido ningún parámetro  
        if [ $# -eq 0 ]
            then
                clear
                echo "No has introducido ningún valor"
                sleep 1
                clear
                read -rp "Nombre de usuario : " nombre
                read -rp "Cantidad de usuarios : " count
                creaUsuarios "$nombre" "$count"
            else
                creaUsuarios "$1" "$2"
        fi
        
    else
        echo "No eres root"
fi