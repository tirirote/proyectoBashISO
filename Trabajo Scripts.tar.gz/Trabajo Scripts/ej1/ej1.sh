#!/bin/bash
#Author: GRUPO 3
#Version: 1.0
#Date: 00-00-00
#Description:
comprueba_apache() {
    echo "Comprobando el servicio apache ... "
    if expr "$(systemctl is-active apache2.service)" == 'active'
        then            
            echo "El servicio SI está activo"
        else
            echo "Error Apache: $(date)" > /root/ApacheError.tmp
    fi

}

if [ "$(id -u)" -eq 0 ] #Comprueba si eres root
    then
        while true; do
        comprueba_apache
        echo "Esperando 60 segundos..."
            for i in $(seq 1 60);
                do
                    echo "Contando $i ..."
                    sleep 1;
                
            done
        done
    else
        echo "No eres root"
fi


