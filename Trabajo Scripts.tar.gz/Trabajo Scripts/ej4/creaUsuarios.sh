#!/bin/bash
#Author: GRUPO 3
#Version: 1.0
#Date: 00-00-00
#Descripcion: El script contiene dos funciones principales: "creaCadaUsuario" y "creaUsuarios". 
#La función "creaCadaUsuario" crea un usuario específico y asigna una contraseña a este usuario. 
#La función "creaUsuarios" crea un número específico de usuarios.
################################################################
# Script para crear usuarios
################################################################
creaCadaUsuario(){

    echo "Creando usuario $1$2 ..."
    if [ $? -eq 0 ]
        then
            sleep 1
            echo "$1$2" >> passwd alumno1
            echo "Asignando contraseña a $1$2..."
            sleep 1
            echo "$1$2:$1$2" >> usuariosCreados-"$(date +%d-%m-%Y)".txt
            echo "Exportando usuario:contraseña a usuariosCreados-$(date).txt"
            sleep 1
        else
        echo "No se ha podido crear el usuario $1"
    fi
}

################################################################
# Script para crear usuarios
################################################################
creaUsuarios() {

    for i in $(seq 1 $2);
        do
            useradd -e 0 "$1$i"
            if [ $? -eq 0 ]
                then
                    creaCadaUsuario "$1" "$i"
                else
                    echo "No se ha podido crear el usuario $1"
            fi


    done
        echo "Terminado."
            
}
################################################################
#Funcion principal de script para crear usuarios
################################################################
if [ "$(id -u)" -eq 0 ] #Comprueba si eres root
    then
        #Si no has introducido ningún parámetro  
        if [ $# -eq 0 ]
            then
                clear
                echo "No has introducido ningún valor"
                sleep 1
                clear
                read -rp "Nombre de usuario : " nombre
                read -rp "Cantidad de usuarios : " count
                creaUsuarios "$nombre" "$count"
            else
                creaUsuarios "$1" "$2"
        fi
        
    else
        echo "No eres root"
fi
