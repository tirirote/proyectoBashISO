#!/bin/bash
#Author: GRUPO 3
#Version: 1.0
#Date: 00-00-00
#Description:
bloquear() {

    sudo passwd -l "$1"
}
desbloquear() {

    sudo passwd -u "$1"
}

mostrarBloqueados(){

    sudo awk -F: '$2 ~ /L/ {print $1}' /etc/shadow
}

cerrarSesion(){

    .
}
menu() {
    echo "---------------------------------"
    echo "---Menú de usuarios bloqueados---"
    echo "---------------------------------"
    echo "1. Usuarios Bloqueados"
    echo "2. Bloquear un Usuaario"
    echo "3. Desbloquear un Usuario"
    echo "4. Cerrar sesión usuario"
    echo "5. Salir"
}
if [ "$(id -u)" -eq 0 ] #Comprueba si eres root
    then

        while true ; do
        menu
        read -rp "Selecciona una opción: " num
        case $num in 
            1)
                #Mostrar listado de usuarios bloq
                mostrarBloqueados
            ;;
            2)
                #Añadir usuario al listado
                read -rp "Nombre del usuario a bloquear :" user
                bloquear "$user"
            ;;
            3)
                #Eliminar usuario del listado
                read -rp "Nombre del usuario a desbloquear :" user
                desbloquear "$user"
            ;;
            4)
                #Cerrar sesión del usuario;
                read -rp "Nombre de usuario al cual cerrarle la sesión en este equipo: " user
                cerrarSesion "$user"
            ;;
            5)
                exit
            ;;
        esac 

done
    else
        echo "No eres root"
        exit
fi

