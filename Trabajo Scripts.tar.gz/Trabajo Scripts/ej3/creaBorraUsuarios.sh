#!/bin/bash
#Author: GRUPO 3
#Version: 1.0
#Date: 00-00-00
#Description:
menu (){

    clear
    echo "1. Crear Usuarios"
    echo 2. Borrar Usuarios
    echo "3. Salir"
}

creaUsuarios(){

    for linea in $(cat usuarios.csv)
        do
            user=$(echo "$linea" | cut -d ":" -f 1)
            pass=$(echo "$linea" | cut -d ":" -f 2)
            nombre=$(echo "$linea" | cut -d ":" -f 3)
            apellido=$(echo "$linea" | cut -d ":" -f 4)
            mail=$(echo "$linea" | cut -d ":" -f 5)
            #Crear usuario
            creaCadaUsuario "$user" "$pass" "$nombre" "$apellido" "$mail"
            sleep 1
    done
}
#Toma los siguientes parámetros por orden 1. $user" 2. $pass" 2. $nombre" 3. "$apellido 5. "$mail"
creaCadaUsuario(){

    clear
    useradd "$1"
    if [ $? -eq 0 ]
        then
            usermod -e "2024-06-31" "$1"
            #sudo usermod -c "$3","$4","$5" "$1"
            echo "$1:$2" | chpasswd -e
            ##
            echo "Creando usuario $1"
            echo "Contraseña: $2"
            echo "Nombre: $3"
            echo "Apellido: $4"
            echo "Mail: $5"
        else
            echo "El usuario $1 no se ha podido crear" 
    fi
    
}

borraUsuarios(){

    for linea in $(cat usuarios.csv)
        do
            user=$(echo "$linea" | cut -d ":" -f 1)
            #Borrando Usuario
            clear
            sudo userdel "$user" >> /dev/null
            if [ $? -eq 0 ]
                then
                    echo "Borrando usuario $user"
                else
                    echo "El usuario $user no se ha podido borrar" 
            fi
            sleep 1
    done
}

if [ "$(id -u)" -eq 0 ] #Comprueba si eres root
    then
    while true
        do
        menu
        read -rp "Elige una opción: " num
        case "$num" in
            1)
                #Crear Usuarios
                creaUsuarios
            ;;
            2)
                #Borar Usuarios
                borraUsuarios
            ;;
            3)
                #Salir
                exit
            ;;
            *)
                echo "Opción Incorrecta"
                sleep 2
            ;;
        esac
    
done
    else
    echo "No eres root"
    exit
fi
